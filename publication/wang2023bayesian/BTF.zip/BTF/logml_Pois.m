function loglik=logml_Pois(z,Y,M,pM,poisalpha, poisbeta)
%d0=length(unique(Y));                       % let x_{j,1},...,x_{j,p0} be the set of included predictors
d0=max(Y)+1;
[z0,m]=unique(sortrows([Y+1 z]),'rows','legacy');      % z0 are the sorted unique combinations of (y,z_{j,1},...,z_{j,p0}), m contains their positions on {1,...,n}
C=tensor(zeros([d0 M]),[d0 M]);             % d0=levels of the response y, M=number of clustered levels of x_{j,1},...,x_{j,p0}
C(z0)=C(z0)+m-[0;m(1:(end-1))];             % add the differences in positions to cells of clT corresponding to the unique combinations -> gives the number of times (y,z_{j,1},...,z_{j,p0}) appears 
Cdata=tenmat(C,1);                          % matrix representation of the tensor C, with rows of the matrix corresponding to dimension 1 i.e. the levels of y
%column represents the amount of 1,2,dots,k_j, row does for y = 0, dots
JJ=size(Cdata);

%logml_Pois(zz(:,ind1),Ynew,MM(ind1),pM(ind1,:),poisalpha,poisbeta)

B = [0:(d0-1)]';
BB = repmat(B, [1 JJ(2)]);

base = BB.*Cdata.data;  %y_t*1{h1,...,hq}
sum_base = sum(base);  %sum_t=0^T  (y_t*1{h1,...,hq});
nbase = sum(Cdata.data); %sum_t=0^T  1{h1,...,hq};

%%%take logs
%%%three parts
part1 = gammaln(BB+1).*Cdata.data;

part1 = -poisalpha*log(poisbeta)-gammaln(poisalpha) - sum(part1);
part1 = sum(part1);

part2 = gammaln(poisalpha+sum_base);
part2 = sum(part2);

part3 = -log(1/poisbeta + nbase).*(poisalpha + sum_base);
part3 = sum(part3);

loglik = part1+part2+part3;


p=size(pM,1);
for j=1:p
    d=sum(pM(j,:)>0);
    loglik=loglik+log(pM(j,M(j))/stirling(d,M(j)));
end
