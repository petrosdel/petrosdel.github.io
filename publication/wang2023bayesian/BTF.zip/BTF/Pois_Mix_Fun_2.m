function [lambda_D, pi_mean] = Pois_Mix_Fun_2(data00, alpha, cate, samplesize)
%[index, lambda_D, pi_mean] = Pois_Mix_Fun_2(data00, alpha, cate, samplesize)
beta = 1;
gamma = 1;

pi_y = gamrnd(ones(1, cate), 1);
pi_y = pi_y/sum(pi_y);

lambda = gamrnd(alpha, beta, 1, cate);

zz_record = zeros(length(data00), samplesize);
lambda_record = zeros(samplesize, cate);
pi_record = zeros(samplesize, cate);
pi_cate = zeros(length(data00), cate);

for i = 1:samplesize

for j = 1:cate
pi_cate(:,j) = log(pi_y(j)) + data00.*log(lambda(j)) -lambda(j);
end
pi_cate = pi_cate - max(pi_cate,[],2);
pi_cate = exp(pi_cate);
pi_cate = pi_cate./sum(pi_cate,2);
pp = mnrnd(1,pi_cate);
zz_record(:,i) = sum(bsxfun(@times,pp,1:cate),2);
nj = sum(pp);
sj = sum(data00.*pp);

pi_y = gamrnd(gamma+nj, 1);
pi_y = pi_y/sum(pi_y);
pi_record(i,:) = pi_y;

lambda = gamrnd(alpha+sj,1./(beta+nj));
lambda_record(i,:) = lambda;
end

samplesize_1 = floor(samplesize/2);

lambda_D = mean(lambda_record(samplesize_1:end,:));
% mean(pi_record(samplesize_1:end,:));
% 
% zzz_test = zz_record(:,samplesize_1+1:end);
% 
% size_zzz_test = size(zzz_test);
% sz = size_zzz_test(2);
% 
% zzz_cate = [];
% for j = 1:cate
% aa = sum(zzz_test == j,2)/sz;
% zzz_cate = [zzz_cate aa];
% end
% 
pi_mean = mean(pi_record(samplesize_1:end,:));
% 
% [value index] = max(zzz_cate,[],2);
end